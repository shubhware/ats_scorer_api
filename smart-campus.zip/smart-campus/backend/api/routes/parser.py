"""
api/routes/parser.py
─────────────────────
POST /api/parser/upload  — Accept a PDF, run Model 1, return parsed JSON instantly.
"""
import gc      # Python's Garbage Collector
import torch   # PyTorch
import os
import uuid
import logging
import asyncio
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from collections import defaultdict

import fitz  # PyMuPDF
import dateparser
from fastapi import APIRouter, File, HTTPException, UploadFile, status
from fastapi.responses import JSONResponse
from gliner import GLiNER

logger = logging.getLogger(__name__)
router = APIRouter()

# ── File Upload Config ────────────────────────────────────────────────────────
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/tmp/uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE_MB = 10
ALLOWED_CONTENT_TYPES = {"application/pdf"}

# =============================================================================
# 1. AI KNOWLEDGE BASE & TAXONOMY
# =============================================================================

TAXONOMY = {
    "Language": {
        "python", "java", "javascript", "typescript", "c", "c++", "c#", "go",
        "golang", "rust", "ruby", "php", "swift", "kotlin", "sql", "bash", "shell", "html", "css"
    },
    "Framework_Tool": {
        "django", "flask", "fastapi", "spring", "spring boot", "react", "angular",
        "vue", "node", "node.js", "tensorflow", "pytorch", "pandas", "docker", "kubernetes",
        "terraform", "aws", "gcp", "azure", "postgresql", "mysql", "mongodb",
        "redis", "kafka", "burp suite", "nmap", "wireshark", "npcap", "scapy",
        "git", "linux", "eks", "ec2", "s3", "cryptojs", "owasp zap"
    },
    "Concept": {
        "microservices", "system design", "ci/cd", "sre", "penetration testing",
        "xss", "cryptography", "aes", "machine learning", "deep learning",
        "agile", "rest", "api", "zero-trust", "mtls"
    }
}

_TAXONOMY_LOOKUP = {term.lower(): category for category, terms in TAXONOMY.items() for term in terms}

PERSONA_SIGNATURES = {
    "Cybersecurity Engineer": {
        "required": ["penetration testing", "xss", "nmap", "wireshark", "npcap", "scapy", "cryptography", "security", "cybersecurity"],
        "supporting": ["python", "bash", "linux", "network"]
    },
    "Backend Developer": {
        "required": ["backend", "api", "microservices", "spring", "django", "flask", "node", "fastapi", "golang", "hibernate"],
        "supporting": ["java", "python", "sql", "mysql", "postgresql", "redis", "docker", "aws"]
    },
    "DevOps / SRE Engineer": {
        "required": ["devops", "docker", "kubernetes", "terraform", "ci/cd", "jenkins", "sre", "eks", "ansible"],
        "supporting": ["aws", "linux", "bash", "python", "cloud"]
    },
    "Software Engineer": {
        "required": ["sap", "software", "c++", "c", "testing", "programming", "abap"],
        "supporting": ["debugging", "agile", "java", "python", "sql"]
    }
}

# =============================================================================
# 2. COMPILED REGEX PATTERNS
# =============================================================================

RESUME_PATTERNS = [
    ("Summary", re.compile(r'^(?:professional\s+)?(?:summary|profile|objective)', re.I)),
    ("Education", re.compile(r'^(?:education(?:al)?|academic|qualifications?)', re.I)),
    ("Experience", re.compile(r'^(?:(?:work|professional)\s+)?experience', re.I)),
    ("Projects", re.compile(r'^(?:projects?|portfolio)', re.I)),
    ("Skills", re.compile(r'^(?:technical\s+)?skills?', re.I))
]

JD_PATTERNS = [
    ("Requirements", re.compile(r'^(?:requirements?|qualifications?|must)', re.I)),
    ("Responsibilities", re.compile(r'^(?:responsibilities?|duties)', re.I)),
    ("Nice_To_Have", re.compile(r'^(?:nice(?:\s+to\s+have)?|preferred?|bonus)', re.I))
]

_DATE_RANGE_RE = re.compile(
    r'(?P<start>(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s*(?:19|20)\d{2}|(?:19|20)\d{2})\s*(?:–|—|-|to)\s*'
    r'(?P<end>(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s*(?:19|20)\d{2}|(?:19|20)\d{2}|[Pp]resent|[Cc]urrent|[Nn]ow)', 
    re.I
)

_KPI_RE = re.compile(
    r'(?:(?P<verb>reduc\w*|improv\w*|increas\w*|achiev\w*|deliver\w*|handl\w*|sav\w*|cut\w*|scal\w*)?\s*(?:by|to|of|at)?\s*'
    r'(?P<value>[\$€£]?\s*\d[\d,\.]*\s*(?:%|percent|x|k|m|b|req/s|rps|ms|users?|requests?|uptime|availability)?))', 
    re.I
)

_JD_EXPERIENCE_RE = re.compile(r'(?P<min>\d+)\s*(?:[-–+]\s*(?P<max>\d+))?\+?\s*(?:years?|yrs?)', re.I)

# =============================================================================
# 3. UNIVERSAL TECH PARSER CLASS
# =============================================================================

class UniversalTechParser:
    def __init__(self, gliner_model=None, threshold: float = 0.40):
        self.model = gliner_model
        self.threshold = threshold
        self.MAX_GLINER_CHARS = 1500
        self.GLINER_OVERLAP = 200

    def parse_resume(self, text: str, candidate_name: str = "Unknown") -> Dict:
        text = self._normalize(text)
        segments = self._segment_text(text, RESUME_PATTERNS)
        
        enriched_segments = {}
        all_skills, all_kpis, all_dates = [], [], []

        for seg_name, seg_text in segments.items():
            if not seg_text.strip(): continue
            
            classified = self._classify_entities(self._extract_entities(seg_text))
            kpis = self._extract_kpis(seg_text)
            dates = self._extract_temporal(seg_text)
            
            enriched_segments[seg_name] = {
                "raw_text": seg_text[:300] + ("..." if len(seg_text) > 300 else ""),
                "entities": classified,
                "kpis": kpis,
                "temporal": dates
            }
            
            all_skills.extend(classified)
            all_kpis.extend(kpis)
            all_dates.extend(dates)

        persona = self._infer_persona([s["entity"].lower() for s in all_skills])
        timeline = self._build_timeline(enriched_segments)
        
        taxonomy_summary = defaultdict(list)
        for skill in all_skills:
            if skill["entity"] not in taxonomy_summary[skill["taxonomy_class"]]:
                taxonomy_summary[skill["taxonomy_class"]].append(skill["entity"])

        return {
            "document_type": "Resume",
            "parser_version": "1.0.0",
            "candidate_name": candidate_name,
            "primary_persona": persona["primary"],
            "secondary_personas": persona["secondary"],
            "persona_confidence": persona["confidence"],
            "career_timeline": timeline,
            "segments": enriched_segments,
            "aggregated": {
                "taxonomy_summary": dict(taxonomy_summary),
                "kpis": all_kpis
            }
        }

    def _segment_text(self, text: str, patterns: list) -> Dict[str, str]:
        lines = text.split("\n")
        sections, current = {"Overview": []}, "Overview"
        for line in lines:
            stripped = line.strip()
            if not stripped: continue
            matched = False
            for name, pattern in patterns:
                if len(stripped) < 60 and pattern.match(stripped):
                    current = name
                    sections[current] = []
                    matched = True
                    break
            if not matched: sections[current].append(stripped)
        return {k: "\n".join(v) for k, v in sections.items() if v}

    def _extract_entities(self, text: str) -> List[Dict]:
        entities = []
        seen = set()
        
        if self.model:
            try:
                labels = ["programming language", "framework", "tool", "concept", "cloud service"]
                start = 0
                while start < len(text):
                    end = min(start + self.MAX_GLINER_CHARS, len(text))
                    raw = self.model.predict_entities(text[start:end], labels, threshold=self.threshold)
                    for e in raw:
                        val = e["text"].strip()
                        if val.lower() not in seen and len(val) > 1:
                            entities.append({"entity": val, "label": e["label"]})
                            seen.add(val.lower())
                    start += self.MAX_GLINER_CHARS - self.GLINER_OVERLAP
            except Exception as e:
                logger.error(f"GLiNER Extraction Error: {e}")
        
        text_l = " " + text.lower() + " "
        for term in sorted(_TAXONOMY_LOOKUP.keys(), key=len, reverse=True):
            if term not in seen and re.search(rf'(?<![\w/-]){re.escape(term)}(?![\w/-])', text_l):
                entities.append({"entity": term, "label": "heuristic"})
                seen.add(term)
                
        return entities

    def _classify_entities(self, entities: List[Dict]) -> List[Dict]:
        classified, seen = [], set()
        for ent in entities:
            entity_key = ent["entity"].lower()
            if entity_key in seen: continue
            seen.add(entity_key)
            
            tax_class = _TAXONOMY_LOOKUP.get(entity_key)
            if not tax_class:
                for term, cls in _TAXONOMY_LOOKUP.items():
                    if term in entity_key or entity_key in term:
                        tax_class = cls; break
            
            classified.append({
                "entity": ent["entity"],
                "taxonomy_class": tax_class or "Framework_Tool"
            })
        return classified

    def _infer_persona(self, skills_lower: List[str]) -> Dict:
        skills_set = set(skills_lower)
        scores = {}
        
        for persona, sig in PERSONA_SIGNATURES.items():
            req = sum(1 for r in sig["required"] if any(r in s for s in skills_set))
            sup = sum(1 for s in sig["supporting"] if any(s in sk for sk in skills_set))
            
            total_score = (req * 3) + sup
            if total_score > 0:
                scores[persona] = total_score
                
        if not scores:
            return {"primary": "Software Engineer", "secondary": [], "confidence": 0.0}
            
        sorted_p = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        total_pts = sum(s for _, s in sorted_p)
        
        return {
            "primary": sorted_p[0][0],
            "secondary": [p[0] for p in sorted_p[1:3]],
            "confidence": round(sorted_p[0][1] / total_pts, 3) if total_pts else 0.0
        }

    def _extract_kpis(self, text: str) -> List[Dict]:
        kpis, seen = [], set()
        for sentence in re.split(r'[.!?\n]+', text):
            for match in _KPI_RE.finditer(sentence):
                val = match.group("value").strip()
                if val and val not in seen and len(val) > 1:
                    seen.add(val)
                    kpis.append({"metric": val, "verb": match.group("verb") or "", "context": sentence.strip()[:150]})
        return kpis

    def _extract_temporal(self, text: str) -> List[Dict]:
        dates = []
        for match in _DATE_RANGE_RE.finditer(text):
            start, end = match.group("start"), match.group("end")
            duration = self._compute_duration(start, end)
            dates.append({
                "type": "date_range", "start": start, "end": end,
                "is_current": end.lower() in ("present", "current", "now"),
                "duration_months": duration
            })
        return dates

    def _extract_jd_experience(self, text: str) -> Dict:
        match = _JD_EXPERIENCE_RE.search(text)
        if match:
            return {
                "min_years": int(match.group("min")),
                "max_years": int(match.group("max")) if match.group("max") else None,
                "raw": match.group(0).strip()
            }
        return {"min_years": None, "max_years": None, "raw": "Not specified"}

    def _compute_duration(self, start_str: str, end_str: str) -> Optional[float]:
        try:
            end_dt = datetime.now() if end_str.lower() in ("present", "current", "now") else dateparser.parse(end_str)
            start_dt = dateparser.parse(start_str)
            if start_dt and end_dt:
                return max(0, (end_dt.year - start_dt.year) * 12 + (end_dt.month - start_dt.month))
        except: pass
        return None

    def _normalize(self, text: str) -> str:
        text = text.replace('\u2013', '-').replace('\u2014', '-').replace('\u2022', '•')
        return re.sub(r'\n{3,}', '\n\n', re.sub(r'[ \t]+', ' ', text)).strip()

    def _build_timeline(self, segments: Dict) -> List[Dict]:
        timeline = []
        for sec in ["Experience", "Projects"]:
            if sec in segments:
                for t in segments[sec].get("temporal", []):
                    timeline.append({"section": sec, "start": t["start"], "end": t["end"], "months": t.get("duration_months")})
        return sorted(timeline, key=lambda x: x.get("start", ""))

# =============================================================================
# 4. LAZY LOAD THE AI 
# =============================================================================

_ai_parser = None

def get_parser():
    global _ai_parser
    if _ai_parser is None:
        logger.info("⏳ Downloading/Initializing Model 1... (This may take a minute on first run)")
        try:
            _gliner_model = GLiNER.from_pretrained("urchade/gliner_small-v2.1")
            _ai_parser = UniversalTechParser(gliner_model=_gliner_model)
            logger.info("✅ Model 1 Loaded Successfully.")
        except Exception as e:
            logger.error(f"❌ Failed to load GLiNER: {e}. Falling back to fast heuristics.")
            _ai_parser = UniversalTechParser(gliner_model=None)
    return _ai_parser

# =============================================================================
# 5. FASTAPI ROUTES (STATELESS)
# =============================================================================

def run_model_1_parser(file_path: str, filename: str = "Unknown") -> dict:
    """Extracts text from PDF and runs the Universal Tech Parser."""
    try:
        doc = fitz.open(file_path)
        full_text = "\n".join(page.get_text() for page in doc)
        doc.close()

        parser = get_parser()
        # 1. INFERENCE MODE: Tells PyTorch absolutely DO NOT store memory history
        with torch.inference_mode():
            result = parser.parse_resume(full_text, candidate_name=filename.replace(".pdf", ""))

        # 2. AGGRESSIVE GARBAGE COLLECTION: Force Python to delete variables and flush RAM immediately
        del full_text
        del doc
        gc.collect()

        return result
        
    except Exception as e:
        logger.error(f"Error parsing PDF: {e}")
        raise ValueError(f"Could not parse PDF: {str(e)}")


@router.post(
    "/upload",
    summary="Upload a PDF and parse it statelessly",
    response_description="Structured JSON produced by the parser",
)
async def upload_and_parse(file: UploadFile = File(...)):
    """
    Accepts a PDF file, parses it, and returns the JSON directly.
    Nothing is saved to the database.
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Only PDF files are accepted. Received: {file.content_type}",
        )

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds {MAX_FILE_SIZE_MB} MB limit.",
        )

    unique_name = f"{uuid.uuid4()}_{file.filename}"
    temp_path = UPLOAD_DIR / unique_name

    try:
        temp_path.write_bytes(contents)
        
        loop = asyncio.get_event_loop()
        parsed_result: dict = await loop.run_in_executor(
            None, run_model_1_parser, str(temp_path), file.filename
        )

        parsed_result["_meta"] = {
            "original_filename": file.filename,
            "file_size_mb": round(size_mb, 3),
            "parsed_at": datetime.now(timezone.utc).isoformat(),
        }

        # Provide a temporary ID so the frontend doesn't throw a rendering error
        parsed_result["_id"] = f"temp_{uuid.uuid4().hex[:8]}"

        return JSONResponse(content=parsed_result, status_code=status.HTTP_200_OK)

    except Exception as exc:
        logger.exception("Parser error for file %s: %s", file.filename, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Parser failed: {str(exc)}",
        )
    finally:
        if temp_path.exists():
            temp_path.unlink()