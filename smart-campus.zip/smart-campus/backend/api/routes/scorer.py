"""
api/routes/scorer.py
─────────────────────
POST /api/scorer/score  — Accept Model 1 JSON, return ATS score + feedback.

Model 2: ATS Scorer & Feedback Generator
- Lightweight hybrid approach: spaCy TF-IDF similarity + heuristic section scoring
- Zero heavy ML models at inference time → fits constrained Docker RAM
- Optionally loads a tiny serialized DistilBERT embedding if present on disk
"""

import gc
import os
import re
import math
import json
import logging
import asyncio
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Optional: path to serialized sklearn TF-IDF vectorizer + cosine model ──────
MODEL_DIR = Path(os.getenv("MODEL_DIR", "/app/model2_artifacts"))

# =============================================================================
# 1. REFERENCE KNOWLEDGE BASE  (no external model required)
# =============================================================================

# Canonical tech-role skill clusters used as "ideal JD" references
ROLE_SKILL_CLUSTERS: Dict[str, Dict[str, List[str]]] = {
    "Cybersecurity Engineer": {
        "must_have": [
            "penetration testing", "vulnerability assessment", "owasp", "nmap",
            "wireshark", "burp suite", "owasp zap", "network security",
            "threat analysis", "cryptography", "linux", "python", "bash",
            "siem", "incident response", "firewall", "ids", "ips"
        ],
        "nice_to_have": [
            "kali linux", "metasploit", "splunk", "elastic", "zero-trust",
            "mtls", "cve", "exploit", "reversing", "malware analysis",
            "aws", "gcp", "docker", "kubernetes", "ci/cd", "soar"
        ],
        "soft_signals": [
            "security", "cyber", "exploit", "threat", "compliance",
            "audit", "risk", "patch", "forensic"
        ]
    },
    "Backend Developer": {
        "must_have": [
            "python", "java", "node", "api", "rest", "sql", "postgresql",
            "mysql", "mongodb", "redis", "microservices", "docker", "git"
        ],
        "nice_to_have": [
            "kubernetes", "kafka", "rabbitmq", "grpc", "graphql",
            "terraform", "aws", "gcp", "azure", "celery", "fastapi",
            "django", "spring boot", "golang"
        ],
        "soft_signals": [
            "scalab", "latency", "throughput", "optimiz", "architect",
            "deploy", "pipeline", "performance"
        ]
    },
    "Software Engineer": {
        "must_have": [
            "python", "java", "c++", "javascript", "typescript", "git",
            "algorithms", "data structures", "sql", "testing", "oop"
        ],
        "nice_to_have": [
            "react", "docker", "cloud", "agile", "system design",
            "ci/cd", "rest", "microservices", "golang", "rust"
        ],
        "soft_signals": [
            "optimiz", "debug", "refactor", "test", "review", "design",
            "architect", "deliver", "agile", "scrum"
        ]
    },
    "DevOps / SRE Engineer": {
        "must_have": [
            "docker", "kubernetes", "terraform", "ci/cd", "linux", "bash",
            "aws", "gcp", "azure", "git", "jenkins", "ansible", "python"
        ],
        "nice_to_have": [
            "helm", "argocd", "prometheus", "grafana", "elk", "splunk",
            "pagerduty", "datadog", "chaos engineering", "slo", "sla"
        ],
        "soft_signals": [
            "reliab", "incident", "uptime", "monitor", "deploy", "automat",
            "infra", "scale", "observ"
        ]
    }
}

# Section-weight configuration
SECTION_WEIGHTS: Dict[str, float] = {
    "Skills":     0.30,
    "Experience": 0.30,
    "Projects":   0.20,
    "Education":  0.10,
    "Overview":   0.10,
}

# =============================================================================
# 2. PYDANTIC REQUEST MODEL
# =============================================================================

class ScorerRequest(BaseModel):
    parsed_resume: Dict[str, Any] = Field(..., description="Raw JSON from Model 1")
    target_role:   Optional[str]  = Field(None, description="Override inferred role")

# =============================================================================
# 3. SCORING ENGINE
# =============================================================================

def _extract_all_text(parsed: Dict) -> str:
    """Flatten all raw_text from every segment into one string."""
    parts = []
    for seg_data in parsed.get("segments", {}).values():
        parts.append(seg_data.get("raw_text", ""))
    return " ".join(parts).lower()


def _extract_skills_flat(parsed: Dict) -> List[str]:
    """Return a deduplicated flat list of entity strings (lowercased)."""
    skills = set()
    for seg_data in parsed.get("segments", {}).values():
        for ent in seg_data.get("entities", []):
            skills.add(ent.get("entity", "").lower())
    # Also include taxonomy aggregated
    for group in parsed.get("aggregated", {}).get("taxonomy_summary", {}).values():
        for s in group:
            skills.add(s.lower())
    return list(skills)


def _jaccard_coverage(candidate: List[str], reference: List[str]) -> float:
    """Token-level soft coverage: what fraction of reference terms appear in candidate text."""
    if not reference:
        return 0.0
    c_set = set(" ".join(candidate))  # char n-gram fallback
    c_text = " ".join(candidate)
    hits = sum(1 for term in reference if term in c_text)
    return round(hits / len(reference), 4)


def _soft_match(text: str, terms: List[str]) -> Tuple[List[str], List[str]]:
    """Return (matched_terms, missing_terms) with substring matching."""
    matched, missing = [], []
    for term in terms:
        if term.lower() in text:
            matched.append(term)
        else:
            missing.append(term)
    return matched, missing


def _score_skills(parsed: Dict, role_cluster: Dict) -> Dict:
    skills_flat = _extract_skills_flat(parsed)
    all_text = _extract_all_text(parsed)

    must = role_cluster["must_have"]
    nice = role_cluster["nice_to_have"]
    soft = role_cluster["soft_signals"]

    must_matched, must_missing  = _soft_match(all_text, must)
    nice_matched, _             = _soft_match(all_text, nice)
    soft_hits = sum(1 for s in soft if s in all_text)

    must_score = len(must_matched) / max(len(must), 1)
    nice_score = len(nice_matched) / max(len(nice), 1)
    soft_score = min(soft_hits / max(len(soft), 1), 1.0)

    raw = (must_score * 0.60) + (nice_score * 0.25) + (soft_score * 0.15)
    score = round(min(raw * 100, 100), 1)

    feedback = []
    if must_missing:
        top_missing = must_missing[:5]
        feedback.append({
            "type": "gap",
            "priority": "high",
            "message": f"Critical skills missing for this role: {', '.join(top_missing)}.",
            "suggestion": f"Add hands-on projects or certifications covering: {', '.join(top_missing[:3])}."
        })
    if len(nice_matched) < len(nice) // 2:
        missing_nice = [t for t in nice if t not in all_text][:4]
        feedback.append({
            "type": "improvement",
            "priority": "medium",
            "message": f"Boost your profile with preferred skills: {', '.join(missing_nice)}.",
            "suggestion": "Even listing familiarity with these tools can improve ATS ranking."
        })
    if score >= 70:
        feedback.append({
            "type": "strength",
            "priority": "info",
            "message": f"Strong skill alignment — {len(must_matched)}/{len(must)} core skills detected.",
            "suggestion": "Ensure skills are mirrored verbatim from target JD."
        })

    return {
        "score": score,
        "matched": must_matched,
        "missing_critical": must_missing,
        "feedback": feedback
    }


def _score_experience(parsed: Dict) -> Dict:
    timeline   = parsed.get("career_timeline", [])
    exp_seg    = parsed.get("segments", {}).get("Experience", {})
    raw_text   = exp_seg.get("raw_text", "")
    kpis       = exp_seg.get("kpis", [])

    total_months = sum(t.get("months") or 0 for t in timeline if t.get("section") == "Experience")
    num_roles    = len([t for t in timeline if t.get("section") == "Experience"])

    # Experience score components
    duration_score = min(total_months / 24, 1.0)           # 2 yrs = full marks
    kpi_score      = min(len(kpis) / 5, 1.0)               # ≥5 quantified bullets = full
    action_verbs   = len(re.findall(
        r'\b(developed|built|designed|improved|reduced|automated|implemented|deployed|led|analyzed|created)\b',
        raw_text, re.I))
    verb_score     = min(action_verbs / 8, 1.0)

    raw   = (duration_score * 0.40) + (kpi_score * 0.35) + (verb_score * 0.25)
    score = round(raw * 100, 1)

    feedback = []
    if total_months < 6:
        feedback.append({
            "type": "gap", "priority": "high",
            "message": "Limited professional experience detected (<6 months).",
            "suggestion": "Add internships, freelance work, open-source contributions, or research assistantships to bulk up the timeline."
        })
    if len(kpis) < 3:
        feedback.append({
            "type": "improvement", "priority": "high",
            "message": "Too few quantified achievements — ATS and recruiters love numbers.",
            "suggestion": "Convert bullet points to 'verb + metric + outcome' format, e.g. 'Reduced false-positive rate by 30% using…'."
        })
    if action_verbs < 4:
        feedback.append({
            "type": "improvement", "priority": "medium",
            "message": "Weak action verbs detected in experience section.",
            "suggestion": "Start each bullet with power verbs: Engineered, Automated, Reduced, Designed, Spearheaded."
        })
    if score >= 65:
        feedback.append({
            "type": "strength", "priority": "info",
            "message": f"Experience section is well-structured with {num_roles} role(s) and {len(kpis)} metric(s).",
            "suggestion": "Maintain consistent 'past tense for past roles' style."
        })

    return {"score": score, "total_months": total_months, "kpi_count": len(kpis), "feedback": feedback}


def _score_projects(parsed: Dict) -> Dict:
    proj_seg  = parsed.get("segments", {}).get("Projects", {})
    raw_text  = proj_seg.get("raw_text", "")
    entities  = proj_seg.get("entities", [])
    kpis      = proj_seg.get("kpis", [])

    tech_count   = len(set(e["entity"] for e in entities))
    kpi_count    = len(kpis)
    # Reward links (github, demo, deployed)
    link_signals = len(re.findall(r'github|gitlab|demo|deployed|live|vercel|heroku|render', raw_text, re.I))
    proj_count   = len(re.findall(r'\|', raw_text))  # pipe-separated tech stacks = project boundary

    tech_score  = min(tech_count / 6, 1.0)
    kpi_score   = min(kpi_count / 4, 1.0)
    link_score  = min(link_signals / 2, 1.0)
    proj_score  = min(proj_count / 3, 1.0)

    raw   = (tech_score * 0.30) + (kpi_score * 0.30) + (link_score * 0.20) + (proj_score * 0.20)
    score = round(raw * 100, 1)

    feedback = []
    if tech_count < 3:
        feedback.append({
            "type": "gap", "priority": "medium",
            "message": "Projects section uses few distinct technologies.",
            "suggestion": "Each project should list its full tech stack. Aim for 3-5 technologies per project."
        })
    if kpi_count < 2:
        feedback.append({
            "type": "improvement", "priority": "medium",
            "message": "Projects lack measurable outcomes.",
            "suggestion": "Add metrics: lines of code, test coverage %, latency improvement, users served, accuracy of models, etc."
        })
    if link_signals == 0:
        feedback.append({
            "type": "improvement", "priority": "medium",
            "message": "No GitHub/live links detected in projects.",
            "suggestion": "Link each project to its GitHub repo or live demo. This is critical for tech recruiters."
        })
    if score >= 60:
        feedback.append({
            "type": "strength", "priority": "info",
            "message": f"Projects showcase {tech_count} distinct technologies with {kpi_count} quantified results.",
            "suggestion": "Pin your best 2-3 projects on GitHub with detailed READMEs."
        })

    return {"score": score, "tech_count": tech_count, "kpi_count": kpi_count, "feedback": feedback}


def _score_education(parsed: Dict) -> Dict:
    edu_seg  = parsed.get("segments", {}).get("Education", {})
    raw_text = edu_seg.get("raw_text", "")

    # Detect GPA/CGPA signals
    gpa_match = re.search(r'(\d+\.\d+)\s*(?:CGPA|GPA|cgpa|gpa)', raw_text)
    pct_match = re.search(r'(\d{2,3}(?:\.\d+)?)\s*%', raw_text)
    degree    = bool(re.search(r'B\.?Tech|B\.?E|B\.?Sc|M\.?Tech|M\.?Sc|BCA|MCA|Bachelor|Master', raw_text, re.I))
    certs     = len(re.findall(r'certif|aws certified|coursera|udemy|cisco|google|microsoft|comptia', raw_text, re.I))

    gpa_score  = 0.0
    gpa_value  = None
    if gpa_match:
        gpa_value = float(gpa_match.group(1))
        gpa_score = min(gpa_value / 10.0, 1.0)
    elif pct_match:
        pct = float(pct_match.group(1))
        gpa_score = min(pct / 100.0, 1.0)

    degree_score = 1.0 if degree else 0.4
    cert_score   = min(certs / 2, 1.0)

    raw   = (degree_score * 0.50) + (gpa_score * 0.30) + (cert_score * 0.20)
    score = round(raw * 100, 1)

    feedback = []
    if not degree:
        feedback.append({
            "type": "gap", "priority": "medium",
            "message": "No recognized degree detected.",
            "suggestion": "Ensure degree name (B.Tech, B.Sc, etc.) is clearly mentioned with institution and year."
        })
    if gpa_value and gpa_value < 7.5:
        feedback.append({
            "type": "improvement", "priority": "low",
            "message": f"CGPA of {gpa_value} is below the 7.5 threshold many companies filter on.",
            "suggestion": "Compensate with strong projects, certifications, and internship experience."
        })
    if certs == 0:
        feedback.append({
            "type": "improvement", "priority": "medium",
            "message": "No industry certifications detected.",
            "suggestion": "For cybersecurity roles: consider CEH, CompTIA Security+, or Cisco CyberOps. These are free/low-cost ATS boosters."
        })
    if certs >= 2:
        feedback.append({
            "type": "strength", "priority": "info",
            "message": f"Good — {certs} certification(s) found. These signal continuous learning.",
            "suggestion": "List certifications with issuer, date, and credential ID/link."
        })

    return {"score": score, "gpa": gpa_value, "certs_count": certs, "feedback": feedback}


def _score_overview(parsed: Dict) -> Dict:
    overview_seg = parsed.get("segments", {}).get("Overview", {})
    raw_text     = overview_seg.get("raw_text", "")
    candidate    = parsed.get("candidate_name", "")

    has_email    = bool(re.search(r'[\w.+-]+@[\w-]+\.[a-z]{2,}', raw_text, re.I))
    has_phone    = bool(re.search(r'[\+\d][\d\s\-\(\)]{8,}', raw_text))
    has_linkedin = bool(re.search(r'linkedin|lnkd\.in', raw_text, re.I))
    has_github   = bool(re.search(r'github\.com', raw_text, re.I))
    has_summary  = len(raw_text) > 150  # meaningful objective/summary present

    contact_score  = ((has_email + has_phone) / 2)
    profile_score  = ((has_linkedin + has_github) / 2)
    summary_score  = 1.0 if has_summary else 0.0

    raw   = (contact_score * 0.40) + (profile_score * 0.30) + (summary_score * 0.30)
    score = round(raw * 100, 1)

    feedback = []
    if not has_linkedin:
        feedback.append({
            "type": "gap", "priority": "high",
            "message": "LinkedIn profile URL not detected.",
            "suggestion": "Add your LinkedIn URL. Most ATS systems parse this as a key contact field."
        })
    if not has_github:
        feedback.append({
            "type": "improvement", "priority": "high",
            "message": "GitHub profile link not found in overview.",
            "suggestion": "For tech roles, GitHub is your portfolio. Add github.com/<username> to the header."
        })
    if not has_summary:
        feedback.append({
            "type": "improvement", "priority": "medium",
            "message": "Objective/summary section appears short or absent.",
            "suggestion": "Write a 2-3 sentence summary tailored to your target role, using keywords from the JD."
        })
    if has_email and has_phone:
        feedback.append({
            "type": "strength", "priority": "info",
            "message": "Contact information complete with email and phone.",
            "suggestion": "Ensure the email looks professional (firstname.lastname@domain.com)."
        })

    return {"score": score, "has_linkedin": has_linkedin, "has_github": has_github, "feedback": feedback}


# =============================================================================
# 4. AGGREGATE SCORER
# =============================================================================

def run_ats_scorer(parsed: Dict, target_role: Optional[str] = None) -> Dict:
    """
    Main inference function.
    Returns a full ATS report with overall score + section breakdowns.
    """
    role = target_role or parsed.get("primary_persona", "Software Engineer")
    cluster = ROLE_SKILL_CLUSTERS.get(role, ROLE_SKILL_CLUSTERS["Software Engineer"])

    # Section scores
    skill_result   = _score_skills(parsed, cluster)
    exp_result     = _score_experience(parsed)
    proj_result    = _score_projects(parsed)
    edu_result     = _score_education(parsed)
    overview_result= _score_overview(parsed)

    section_scores = {
        "Skills":     skill_result["score"],
        "Experience": exp_result["score"],
        "Projects":   proj_result["score"],
        "Education":  edu_result["score"],
        "Overview":   overview_result["score"],
    }

    # Weighted overall
    overall = sum(
        section_scores[sec] * SECTION_WEIGHTS.get(sec, 0.0)
        for sec in section_scores
    )
    overall = round(overall, 1)

    # ATS tier label
    if overall >= 80:
        tier, tier_color = "Excellent", "emerald"
    elif overall >= 65:
        tier, tier_color = "Good", "blue"
    elif overall >= 50:
        tier, tier_color = "Average", "yellow"
    else:
        tier, tier_color = "Needs Work", "red"

    # Compile all priority feedback items
    all_feedback = []
    for section, result in [
        ("Skills",     skill_result),
        ("Experience", exp_result),
        ("Projects",   proj_result),
        ("Education",  edu_result),
        ("Overview",   overview_result),
    ]:
        for fb in result.get("feedback", []):
            fb["section"] = section
            all_feedback.append(fb)

    # Sort: high → medium → low → info
    priority_order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    all_feedback.sort(key=lambda x: priority_order.get(x.get("priority", "info"), 3))

    gc.collect()

    return {
        "model_version": "2.0.0",
        "target_role":   role,
        "overall_score": overall,
        "tier":          tier,
        "tier_color":    tier_color,
        "section_scores": section_scores,
        "section_weights": SECTION_WEIGHTS,
        "details": {
            "skills": {
                "matched": skill_result["matched"],
                "missing_critical": skill_result["missing_critical"],
            },
            "experience": {
                "total_months": exp_result["total_months"],
                "kpi_count": exp_result["kpi_count"],
            },
            "projects": {
                "tech_count": proj_result["tech_count"],
                "kpi_count": proj_result["kpi_count"],
            },
            "education": {
                "gpa": edu_result["gpa"],
                "certs_count": edu_result["certs_count"],
            },
            "overview": {
                "has_linkedin": overview_result["has_linkedin"],
                "has_github":   overview_result["has_github"],
            },
        },
        "feedback": all_feedback,
    }


# =============================================================================
# 5. FASTAPI ROUTE
# =============================================================================

@router.post(
    "/score",
    summary="ATS-score a Model 1 parsed resume JSON",
    response_description="ATS score, section breakdown, and granular feedback",
)
async def score_resume(request: ScorerRequest):
    """
    Accepts the JSON output of Model 1's /api/parser/upload and returns:
    - overall_score (0-100)
    - section_scores (per section)
    - tier label
    - granular feedback list (type, priority, message, suggestion)
    """
    if not request.parsed_resume:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="parsed_resume cannot be empty.",
        )
    if request.parsed_resume.get("document_type") != "Resume":
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Payload does not look like a Model 1 Resume JSON (missing document_type='Resume').",
        )

    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None, run_ats_scorer, request.parsed_resume, request.target_role
        )
        return JSONResponse(content=result, status_code=status.HTTP_200_OK)

    except Exception as exc:
        logger.exception("ATS Scorer error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Scorer failed: {str(exc)}",
        )
