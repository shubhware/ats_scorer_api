"""
database.py
───────────
Async MongoDB connection utility using Motor.
Reads connection settings from environment variables that are injected
by Docker Compose (see docker-compose.yml → backend.environment).
"""
import os
import logging
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

logger = logging.getLogger(__name__)

# ── Settings (resolved from environment) ──────────────────────────────────────
MONGO_URI: str = os.getenv(
    "MONGO_URI",
    "mongodb://admin:campus_secret@localhost:27017/smart_campus?authSource=admin",
)
MONGO_DB_NAME: str = os.getenv("MONGO_DB_NAME", "smart_campus")

# ── Module-level client (shared across the app lifecycle) ─────────────────────
_client: AsyncIOMotorClient | None = None
_db: AsyncIOMotorDatabase | None = None


def get_client() -> AsyncIOMotorClient:
    """Return the shared Motor client, initialising it on first call."""
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(
            MONGO_URI,
            serverSelectionTimeoutMS=5_000,   # fail fast during local dev
            connectTimeoutMS=5_000,
        )
        logger.info("Motor client created → %s / %s", MONGO_URI, MONGO_DB_NAME)
    return _client


def get_db() -> AsyncIOMotorDatabase:
    """Return the default database handle."""
    global _db
    if _db is None:
        _db = get_client()[MONGO_DB_NAME]
    return _db


async def connect_db() -> None:
    """
    Called from FastAPI lifespan on startup.
    Runs a lightweight ping to verify the connection is reachable.
    """
    try:
        db = get_db()
        await db.command("ping")
        logger.info("✅  MongoDB connection verified (db=%s)", MONGO_DB_NAME)
    except Exception as exc:
        logger.error("❌  MongoDB connection failed: %s", exc)
        raise


async def close_db() -> None:
    """Called from FastAPI lifespan on shutdown."""
    global _client, _db
    if _client is not None:
        _client.close()
        _client = None
        _db = None
        logger.info("MongoDB connection closed.")


# ── Collection helpers ────────────────────────────────────────────────────────
def parsed_docs_collection():
    """Collection that stores all parsed resume / JD documents."""
    return get_db()["parsed_documents"]


def jobs_collection():
    """Collection for job postings (future use)."""
    return get_db()["jobs"]


def candidates_collection():
    """Collection for candidate profiles (future use)."""
    return get_db()["candidates"]
