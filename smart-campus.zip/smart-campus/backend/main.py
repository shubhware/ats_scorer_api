"""
main.py  (updated for Model 2)
───────
FastAPI application entry-point for the Smart Campus Recruitment System.
Registers CORS middleware, mounts all routers, and manages the DB lifespan.

CHANGE LOG (Model 2 addition):
  - Import scorer router
  - Mount at /api/scorer
"""
from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import connect_db, close_db
from api.routes import parser  as parser_router   # Model 1 — unchanged
from api.routes import scorer  as scorer_router   # Model 2 — NEW

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


# ── Lifespan (replaces deprecated on_event) ───────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀  Smart Campus backend starting…")
    await connect_db()
    yield
    logger.info("🛑  Smart Campus backend shutting down…")
    await close_db()


# ── Application factory ───────────────────────────────────────────────────────
app = FastAPI(
    title="Smart Campus Recruitment API",
    description="AI-powered Resume & Job Description parser + ATS scorer for campus placements.",
    version="2.0.0",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(
    parser_router.router,
    prefix="/api/parser",
    tags=["Parser — Model 1"],
)

# ▼ NEW: Model 2 scorer
app.include_router(
    scorer_router.router,
    prefix="/api/scorer",
    tags=["Scorer — Model 2"],
)


# ── Health-check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": "smart-campus-backend", "version": "2.0.0"}
