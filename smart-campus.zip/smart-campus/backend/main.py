"""
main.py
───────
FastAPI application entry-point for the Smart Campus Recruitment System.
Registers CORS middleware, mounts all routers, and manages the DB lifespan.
"""
from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import connect_db, close_db
from api.routes import parser as parser_router

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


# ── Lifespan (replaces deprecated on_event) ───────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀  Smart Campus backend starting…")
    await connect_db()
    yield
    logger.info("🛑  Smart Campus backend shutting down…")
    await close_db()


# ── Application factory ───────────────────────────────────────────────────────
app = FastAPI(
    title="Smart Campus Recruitment API",
    description="AI-powered Resume & Job Description parser for campus placements.",
    version="1.0.0",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────────────────────
# Allow the Vite dev server (port 5173) running on the host to call the API.
# In production replace with your real domain.
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",   # fallback for CRA / other setups
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(
    parser_router.router,
    prefix="/api/parser",
    tags=["Parser"],
)


# ── Health-check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": "smart-campus-backend"}
