import React from "react";
import { useParser, STATUS } from "./hooks/useParser";
import DropZone from "./components/DropZone";
import StatusBar from "./components/StatusBar";
import ResultSummary from "./components/ResultSummary";
import JsonViewer from "./components/JsonViewer";

export default function App() {
  const { status, progress, result, error, fileName, parse, reset } = useParser();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center mt-10 mb-12">
          <h1 className="text-4xl font-bold text-slate-100 tracking-tight mb-3">
            Smart Campus <span className="text-brand-500">Parser</span>
          </h1>
          <p className="text-slate-400 text-lg">
            Powered by Model 1: Universal Tech Resume & JD NLP Pipeline
          </p>
        </div>

        {/* Upload Zone */}
        {status === STATUS.IDLE && (
          <DropZone onFile={parse} disabled={false} />
        )}

        {/* Loading / Error States */}
        {(status === STATUS.UPLOADING || status === STATUS.PARSING || status === STATUS.ERROR) && (
          <StatusBar 
            status={status} 
            progress={progress} 
            fileName={fileName} 
            error={error} 
          />
        )}

        {/* Success Results */}
        {status === STATUS.SUCCESS && result && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center bg-emerald-500/10 border border-emerald-500/20 px-5 py-3 rounded-xl">
              <span className="text-emerald-400 text-sm font-medium flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Successfully Parsed {fileName}
              </span>
              <button 
                onClick={reset} 
                className="text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg transition-colors duration-200"
              >
                Parse Another File
              </button>
            </div>
            
            <ResultSummary data={result} />
            <JsonViewer data={result} title="Raw Model 1 JSON Output" />
          </div>
        )}

      </div>
    </div>
  );
}