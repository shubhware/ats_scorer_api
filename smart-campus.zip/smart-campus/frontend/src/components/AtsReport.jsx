/**
 * AtsReport.jsx
 * ─────────────
 * Renders the full Model 2 ATS report:
 *   - Radial score gauge
 *   - Section bar chart
 *   - Actionable feedback cards (color-coded by priority)
 *
 * Props:
 *   data  {object}  — response from POST /api/scorer/score
 */

import React, { useEffect, useRef, useState } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// Radial Gauge
// ─────────────────────────────────────────────────────────────────────────────
function RadialGauge({ score, tier, tierColor }) {
  const [displayed, setDisplayed] = useState(0);
  const r = 70;
  const circ = 2 * Math.PI * r;
  const offset = circ - (displayed / 100) * circ;

  // Colour maps
  const strokeMap = {
    emerald: "#10b981",
    blue:    "#3b82f6",
    yellow:  "#f59e0b",
    red:     "#ef4444",
  };
  const bgMap = {
    emerald: "rgba(16,185,129,0.12)",
    blue:    "rgba(59,130,246,0.12)",
    yellow:  "rgba(245,158,11,0.12)",
    red:     "rgba(239,68,68,0.12)",
  };
  const textMap = {
    emerald: "text-emerald-400",
    blue:    "text-blue-400",
    yellow:  "text-yellow-400",
    red:     "text-red-400",
  };

  const stroke  = strokeMap[tierColor]  || strokeMap.blue;
  const bgColor = bgMap[tierColor]      || bgMap.blue;
  const textCls = textMap[tierColor]    || textMap.blue;

  // Animate counter
  useEffect(() => {
    let frame;
    let start = null;
    const duration = 1200;
    const animate = (ts) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(ease * score));
      if (progress < 1) frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [score]);

  return (
    <div
      className="flex flex-col items-center justify-center rounded-2xl p-6"
      style={{ background: bgColor, border: `1px solid ${stroke}33` }}
    >
      <svg width="180" height="180" viewBox="0 0 180 180">
        {/* Track */}
        <circle
          cx="90" cy="90" r={r}
          fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="12"
        />
        {/* Progress */}
        <circle
          cx="90" cy="90" r={r}
          fill="none"
          stroke={stroke}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          transform="rotate(-90 90 90)"
          style={{ transition: "stroke-dashoffset 0.05s linear" }}
        />
        {/* Score text */}
        <text x="90" y="84" textAnchor="middle" fontSize="32" fontWeight="700" fill="white" fontFamily="monospace">
          {displayed}
        </text>
        <text x="90" y="104" textAnchor="middle" fontSize="12" fill="rgba(255,255,255,0.5)" fontFamily="sans-serif">
          out of 100
        </text>
      </svg>
      <span className={`mt-2 text-lg font-bold tracking-wide ${textCls}`}>{tier}</span>
      <span className="text-xs text-slate-400 mt-1 font-mono">ATS Compatibility Score</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Section Bar
// ─────────────────────────────────────────────────────────────────────────────
function SectionBar({ label, score, weight }) {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setWidth(score), 100);
    return () => clearTimeout(t);
  }, [score]);

  const color =
    score >= 75 ? "#10b981" :
    score >= 55 ? "#3b82f6" :
    score >= 35 ? "#f59e0b" :
                  "#ef4444";

  return (
    <div className="mb-3">
      <div className="flex justify-between text-xs mb-1">
        <span className="text-slate-300 font-medium">{label}</span>
        <span className="text-slate-400 font-mono">
          {score.toFixed(0)}/100 · <span className="text-slate-500">{(weight * 100).toFixed(0)}% wt</span>
        </span>
      </div>
      <div className="h-2 bg-slate-700/60 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{ width: `${width}%`, background: color }}
        />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Feedback Card
// ─────────────────────────────────────────────────────────────────────────────
const PRIORITY_CONFIG = {
  high:   { border: "border-red-500/40",     bg: "bg-red-500/8",     icon: "⚠",  badge: "bg-red-500/20 text-red-400",     label: "High Priority" },
  medium: { border: "border-yellow-500/40",  bg: "bg-yellow-500/8",  icon: "→",  badge: "bg-yellow-500/20 text-yellow-400", label: "Medium" },
  low:    { border: "border-slate-500/40",   bg: "bg-slate-700/30",  icon: "ℹ",  badge: "bg-slate-600/40 text-slate-400",  label: "Low" },
  info:   { border: "border-emerald-500/30", bg: "bg-emerald-500/8", icon: "✓",  badge: "bg-emerald-500/20 text-emerald-400", label: "Strength" },
};

const SECTION_BADGE_COLOR = {
  Skills:     "bg-purple-500/20 text-purple-300",
  Experience: "bg-blue-500/20 text-blue-300",
  Projects:   "bg-cyan-500/20 text-cyan-300",
  Education:  "bg-amber-500/20 text-amber-300",
  Overview:   "bg-slate-500/20 text-slate-300",
};

function FeedbackCard({ item, index }) {
  const cfg = PRIORITY_CONFIG[item.priority] || PRIORITY_CONFIG.info;
  const sectionCls = SECTION_BADGE_COLOR[item.section] || "bg-slate-600/20 text-slate-400";

  return (
    <div
      className={`rounded-xl border ${cfg.border} ${cfg.bg} p-4 flex gap-3`}
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <span className="text-lg leading-none mt-0.5 select-none">{cfg.icon}</span>
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap gap-2 mb-1.5">
          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${cfg.badge}`}>
            {cfg.label}
          </span>
          <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${sectionCls}`}>
            {item.section}
          </span>
        </div>
        <p className="text-sm text-slate-200 font-medium leading-snug">{item.message}</p>
        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
          <span className="text-slate-500">Fix: </span>{item.suggestion}
        </p>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Skill Chips
// ─────────────────────────────────────────────────────────────────────────────
function SkillChips({ label, skills, variant }) {
  if (!skills || skills.length === 0) return null;
  const cls = variant === "match"
    ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
    : "bg-red-500/15 text-red-300 border border-red-500/30";

  return (
    <div className="mb-4">
      <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {skills.map((s) => (
          <span key={s} className={`text-xs px-2 py-1 rounded-lg font-mono ${cls}`}>{s}</span>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main AtsReport Component
// ─────────────────────────────────────────────────────────────────────────────
export default function AtsReport({ data }) {
  const [activeTab, setActiveTab] = useState("feedback");

  const {
    overall_score, tier, tier_color, target_role,
    section_scores, section_weights, feedback, details,
    model_version,
  } = data;

  const gaps     = feedback.filter((f) => f.type === "gap");
  const improves = feedback.filter((f) => f.type === "improvement");
  const strengths= feedback.filter((f) => f.type === "strength");

  return (
    <div className="space-y-6">
      {/* ── Header badge ─────────────────────────────── */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-slate-700 to-transparent" />
        <span className="text-xs font-mono text-slate-500 px-3 py-1 border border-slate-700 rounded-full">
          Model 2 · ATS Scorer v{model_version}
        </span>
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-slate-700 to-transparent" />
      </div>

      {/* ── Top: Gauge + Section Scores ─────────────── */}
      <div className="grid md:grid-cols-2 gap-5">
        {/* Gauge */}
        <div className="flex flex-col items-center justify-center">
          <RadialGauge score={overall_score} tier={tier} tierColor={tier_color} />
          <p className="text-xs text-slate-500 mt-3 text-center">
            Scored against <span className="text-slate-300 font-semibold">{target_role}</span> role profile
          </p>
        </div>

        {/* Section scores */}
        <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-5">
          <h3 className="text-sm font-semibold text-slate-300 mb-4 tracking-wide uppercase">
            Section Breakdown
          </h3>
          {Object.entries(section_scores).map(([sec, score]) => (
            <SectionBar
              key={sec}
              label={sec}
              score={score}
              weight={section_weights[sec] || 0}
            />
          ))}
        </div>
      </div>

      {/* ── Skill Match Panel ───────────────────────── */}
      <div className="bg-slate-800/40 rounded-2xl border border-slate-700/40 p-5">
        <h3 className="text-sm font-semibold text-slate-300 mb-4 tracking-wide uppercase">
          Skill Analysis for {target_role}
        </h3>
        <SkillChips label="Detected Skills (ATS Matched)" skills={details?.skills?.matched} variant="match" />
        <SkillChips label="Critical Skills Missing" skills={details?.skills?.missing_critical} variant="missing" />

        {/* Quick stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2">
          {[
            { label: "Experience", value: `${Math.round((details?.experience?.total_months || 0))} mo` },
            { label: "KPIs Found", value: (details?.experience?.kpi_count || 0) + (details?.projects?.kpi_count || 0) },
            { label: "LinkedIn",   value: details?.overview?.has_linkedin ? "✓" : "✗" },
            { label: "GitHub",     value: details?.overview?.has_github   ? "✓" : "✗" },
          ].map(({ label, value }) => (
            <div key={label} className="bg-slate-900/60 rounded-xl p-3 text-center border border-slate-700/30">
              <p className="text-lg font-bold text-slate-100 font-mono">{value}</p>
              <p className="text-xs text-slate-500 mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Feedback Tabs ───────────────────────────── */}
      <div className="bg-slate-800/40 rounded-2xl border border-slate-700/40 overflow-hidden">
        {/* Tab bar */}
        <div className="flex border-b border-slate-700/50">
          {[
            { key: "feedback", label: `All (${feedback.length})` },
            { key: "gaps",     label: `Gaps (${gaps.length})`,     color: "text-red-400" },
            { key: "improve",  label: `Improve (${improves.length})`, color: "text-yellow-400" },
            { key: "strength", label: `Strengths (${strengths.length})`, color: "text-emerald-400" },
          ].map(({ key, label, color }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex-1 text-xs py-3 px-2 font-semibold transition-colors duration-150 ${
                activeTab === key
                  ? "bg-slate-700/50 text-slate-100 border-b-2 border-brand-500"
                  : `text-slate-500 hover:text-slate-300 ${color || ""}`
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="p-4 space-y-3 max-h-[480px] overflow-y-auto scrollbar-thin scrollbar-track-slate-900 scrollbar-thumb-slate-600">
          {(activeTab === "feedback" ? feedback :
            activeTab === "gaps"    ? gaps      :
            activeTab === "improve" ? improves  :
                                      strengths
          ).map((item, i) => (
            <FeedbackCard key={i} item={item} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
