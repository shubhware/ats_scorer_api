/**
 * DropZone.jsx
 * ─────────────
 * Drag-and-drop + click-to-browse PDF upload zone.
 * Accepts a single PDF file and calls onFile(file) when one is selected.
 */
import { useRef, useState, useCallback } from "react";

export default function DropZone({ onFile, disabled }) {
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback(
    (file) => {
      if (!file) return;
      if (file.type !== "application/pdf") {
        alert("Only PDF files are accepted. Please upload a .pdf file.");
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        alert("File exceeds the 10 MB limit. Please upload a smaller PDF.");
        return;
      }
      onFile(file);
    },
    [onFile]
  );

  /* ── Drag handlers ────────────────────────────────────────────────── */
  const onDrop = useCallback(
    (e) => {
      e.preventDefault();
      setIsDragging(false);
      if (disabled) return;
      handleFile(e.dataTransfer.files[0]);
    },
    [disabled, handleFile]
  );

  const onDragOver = (e) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  };

  const onDragLeave = (e) => {
    // Only clear when truly leaving the zone (not entering a child element)
    if (!e.currentTarget.contains(e.relatedTarget)) {
      setIsDragging(false);
    }
  };

  /* ── Input change handler ─────────────────────────────────────────── */
  const onInputChange = (e) => {
    handleFile(e.target.files[0]);
    // Reset input so the same file can be re-uploaded
    e.target.value = "";
  };

  return (
    <div
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-label="Upload PDF file"
      onClick={() => !disabled && inputRef.current?.click()}
      onKeyDown={(e) =>
        (e.key === "Enter" || e.key === " ") && !disabled && inputRef.current?.click()
      }
      onDrop={onDrop}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      className={`
        relative flex flex-col items-center justify-center gap-4
        rounded-2xl border-2 border-dashed px-8 py-16
        cursor-pointer transition-all duration-200 select-none outline-none
        focus-visible:ring-2 focus-visible:ring-brand-500 focus-visible:ring-offset-2
        focus-visible:ring-offset-slate-950
        ${
          isDragging
            ? "border-brand-500 bg-brand-500/10 scale-[1.015] shadow-lg shadow-brand-500/10"
            : "border-slate-600 bg-slate-800/50 hover:border-brand-500/60 hover:bg-slate-800"
        }
        ${disabled ? "pointer-events-none opacity-40 cursor-not-allowed" : ""}
      `}
    >
      {/* Animated icon */}
      <div
        className={`
          flex h-16 w-16 items-center justify-center rounded-2xl
          transition-all duration-200
          ${isDragging ? "bg-brand-500/25 scale-110" : "bg-slate-700"}
        `}
      >
        {isDragging ? (
          /* Arrow-down icon when dragging */
          <svg
            className="h-8 w-8 text-brand-400 animate-bounce"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        ) : (
          /* Document icon at rest */
          <svg
            className="h-8 w-8 text-slate-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586
                 a1 1 0 01.707.293l5.414 5.414A1 1 0 0120 9.414V19
                 a2 2 0 01-2 2z"
            />
          </svg>
        )}
      </div>

      {/* Text */}
      <div className="text-center space-y-1">
        <p className="text-base font-semibold text-slate-200">
          {isDragging ? "Release to upload" : "Drop your PDF here"}
        </p>
        <p className="text-sm text-slate-400">
          or{" "}
          <span className="text-brand-400 underline underline-offset-2 decoration-dashed">
            browse files
          </span>
        </p>
      </div>

      {/* Constraints badge */}
      <div className="flex items-center gap-3 text-xs text-slate-500">
        <span className="flex items-center gap-1">
          <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          PDF only
        </span>
        <span className="text-slate-700">·</span>
        <span className="flex items-center gap-1">
          <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4
                 M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
          </svg>
          Max 10 MB
        </span>
        <span className="text-slate-700">·</span>
        <span>Resume or JD</span>
      </div>

      {/* Hidden native input */}
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf"
        className="hidden"
        onChange={onInputChange}
        disabled={disabled}
      />
    </div>
  );
}
