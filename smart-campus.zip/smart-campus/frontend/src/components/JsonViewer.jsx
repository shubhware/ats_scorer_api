/**
 * JsonViewer.jsx
 * ──────────────
 * Syntax-highlighted, collapsible JSON tree for displaying parser output.
 * Uses recursive rendering — no external library needed.
 */
import { useState } from "react";

// ── Token colours ─────────────────────────────────────────────────────────────
const colour = {
  key:     "text-sky-400",
  string:  "text-emerald-400",
  number:  "text-amber-400",
  boolean: "text-violet-400",
  null:    "text-rose-400",
  brace:   "text-slate-400",
};

function JsonNode({ data, depth = 0 }) {
  const [collapsed, setCollapsed] = useState(depth >= 2);
  const indent = "  ".repeat(depth);
  const childIndent = "  ".repeat(depth + 1);

  if (data === null) return <span className={colour.null}>null</span>;
  if (typeof data === "boolean")
    return <span className={colour.boolean}>{String(data)}</span>;
  if (typeof data === "number")
    return <span className={colour.number}>{data}</span>;
  if (typeof data === "string")
    return <span className={colour.string}>"{data}"</span>;

  if (Array.isArray(data)) {
    if (data.length === 0) return <span className={colour.brace}>[]</span>;
    return (
      <span>
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="mr-1 text-slate-500 hover:text-slate-300 focus:outline-none"
        >
          {collapsed ? "▶" : "▼"}
        </button>
        <span className={colour.brace}>[</span>
        {collapsed ? (
          <span
            className="cursor-pointer text-slate-500 hover:text-slate-300"
            onClick={() => setCollapsed(false)}
          >
            {" "}
            {data.length} items{" "}
          </span>
        ) : (
          <>
            {"\n"}
            {data.map((item, i) => (
              <span key={i}>
                {childIndent}
                <JsonNode data={item} depth={depth + 1} />
                {i < data.length - 1 ? "," : ""}
                {"\n"}
              </span>
            ))}
            {indent}
          </>
        )}
        <span className={colour.brace}>]</span>
      </span>
    );
  }

  if (typeof data === "object") {
    const keys = Object.keys(data);
    if (keys.length === 0) return <span className={colour.brace}>{"{}"}</span>;
    return (
      <span>
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="mr-1 text-slate-500 hover:text-slate-300 focus:outline-none"
        >
          {collapsed ? "▶" : "▼"}
        </button>
        <span className={colour.brace}>{"{"}</span>
        {collapsed ? (
          <span
            className="cursor-pointer text-slate-500 hover:text-slate-300"
            onClick={() => setCollapsed(false)}
          >
            {" "}
            {keys.length} keys{" "}
          </span>
        ) : (
          <>
            {"\n"}
            {keys.map((key, i) => (
              <span key={key}>
                {childIndent}
                <span className={colour.key}>"{key}"</span>
                <span className="text-slate-400">: </span>
                <JsonNode data={data[key]} depth={depth + 1} />
                {i < keys.length - 1 ? "," : ""}
                {"\n"}
              </span>
            ))}
            {indent}
          </>
        )}
        <span className={colour.brace}>{"}"}</span>
      </span>
    );
  }

  return <span>{String(data)}</span>;
}

export default function JsonViewer({ data, title }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-2xl border border-slate-700 bg-slate-900 overflow-hidden">
      {/* Header bar */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-slate-700 bg-slate-800/60">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-sm font-medium text-slate-300">
            {title || "Parsed Output"}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium
                     text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
        >
          {copied ? (
            <>
              <svg className="h-3.5 w-3.5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Copied!
            </>
          ) : (
            <>
              <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              Copy JSON
            </>
          )}
        </button>
      </div>

      {/* JSON body */}
      <pre className="json-scroll overflow-auto max-h-[60vh] p-5 text-xs leading-5 font-mono text-slate-300">
        <JsonNode data={data} depth={0} />
      </pre>
    </div>
  );
}
