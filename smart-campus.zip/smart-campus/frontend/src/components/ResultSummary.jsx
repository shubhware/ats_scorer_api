/**
 * ResultSummary.jsx
 * ──────────────────
 * Renders a visual summary card above the raw JSON viewer.
 * Auto-detects whether the document is a Resume or Job_Description
 * and renders the appropriate fields from the Model 1 output schema.
 */

/* ── Helpers ──────────────────────────────────────────────────────────────── */

/** Safely extract a display label from various entity shapes Model 1 returns */
function entityLabel(item) {
  if (typeof item === "string") return item;
  return item?.entity ?? item?.name ?? JSON.stringify(item);
}

/** Pill/chip component for skill tags */
function Chip({ label, variant = "brand" }) {
  const variants = {
    brand:  "bg-brand-500/15 border-brand-500/30 text-brand-300",
    violet: "bg-violet-500/15 border-violet-500/30 text-violet-300",
    amber:  "bg-amber-500/10  border-amber-500/25  text-amber-300",
    slate:  "bg-slate-700/60  border-slate-600      text-slate-300",
  };
  return (
    <span
      className={`
        inline-flex items-center rounded-full border px-2.5 py-0.5
        text-xs font-medium leading-5 ${variants[variant]}
      `}
    >
      {label}
    </span>
  );
}

/** Labelled stat block used in the metrics row */
function Stat({ label, value, sub }) {
  if (value == null) return null;
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">
        {label}
      </span>
      <span className="text-sm font-bold text-white">{value}</span>
      {sub && <span className="text-[10px] text-slate-500">{sub}</span>}
    </div>
  );
}

/* ── Main component ───────────────────────────────────────────────────────── */

export default function ResultSummary({ data }) {
  if (!data) return null;

  const isResume = data.document_type === "Resume";
  const isJD     = data.document_type === "Job_Description";

  /* ── Derived values ─────────────────────────────────────────────── */
  const confidencePct =
    data.persona_confidence != null
      ? `${Math.round(data.persona_confidence * 100)}%`
      : null;

  const expRequired =
    isJD && data.experience_required
      ? `${data.experience_required.min_years}${
          data.experience_required.max_years
            ? `–${data.experience_required.max_years}`
            : "+"
        } yrs`
      : null;

  const totalMonths = isResume
    ? data.career_timeline?.reduce((acc, t) => acc + (t.months ?? 0), 0)
    : null;

  const experienceYears =
    totalMonths != null ? `~${(totalMonths / 12).toFixed(1)} yrs` : null;

  const mustHaveSkills  = (data.must_have_skills  ?? []).slice(0, 10);
  const niceToHaveSkills= (data.nice_to_have_skills ?? []).slice(0, 6);
  const secondaryPersonas = data.secondary_personas ?? [];

  /* ── Badge colour for document type ────────────────────────────── */
  const docTypeBadge = isResume
    ? "bg-brand-500/15 border-brand-500/30 text-brand-300"
    : isJD
    ? "bg-violet-500/15 border-violet-500/30 text-violet-300"
    : "bg-slate-700 border-slate-600 text-slate-300";

  const docTypeLabel = data.document_type?.replace(/_/g, " ") ?? "Document";

  return (
    <div className="rounded-xl border border-slate-700 bg-slate-800/60 overflow-hidden">

      {/* ── Header band ─────────────────────────────────────────────── */}
      <div className="px-5 pt-5 pb-4 space-y-3">

        {/* Row 1: document type badge + parser version */}
        <div className="flex flex-wrap items-center gap-2">
          <span className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${docTypeBadge}`}>
            {docTypeLabel}
          </span>
          <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10
                           px-2.5 py-0.5 text-xs font-semibold text-emerald-400">
            v{data.parser_version ?? "—"}
          </span>
          {confidencePct && (
            <span className="rounded-full border border-amber-500/25 bg-amber-500/10
                             px-2.5 py-0.5 text-xs font-semibold text-amber-400">
              {confidencePct} confidence
            </span>
          )}
        </div>

        {/* Row 2: primary title */}
        <div>
          <h2 className="text-xl font-bold leading-tight text-white">
            {isResume ? data.candidate_name : data.job_title ?? "Untitled"}
          </h2>
          {(data.primary_persona || data.target_persona) && (
            <p className={`mt-0.5 text-sm font-medium ${isResume ? "text-brand-400" : "text-violet-400"}`}>
              {isResume ? data.primary_persona : data.target_persona}
            </p>
          )}
        </div>

        {/* Row 3: quick stats */}
        <div className="flex flex-wrap gap-x-8 gap-y-2 pt-1">
          {isResume && (
            <Stat
              label="Est. Experience"
              value={experienceYears}
              sub={`${totalMonths} months across timeline`}
            />
          )}
          {isJD && (
            <Stat
              label="Experience Required"
              value={expRequired}
              sub={data.experience_required?.raw}
            />
          )}
          {data.career_timeline && (
            <Stat
              label="Timeline Entries"
              value={data.career_timeline.length}
              sub="sections detected"
            />
          )}
          {isJD && data.must_have_skills && (
            <Stat
              label="Must-Have Skills"
              value={data.must_have_skills.length}
              sub="entities extracted"
            />
          )}
          {isResume && data.segments && (
            <Stat
              label="Sections Parsed"
              value={Object.keys(data.segments).length}
              sub={Object.keys(data.segments).join(", ")}
            />
          )}
        </div>
      </div>

      {/* ── Divider ─────────────────────────────────────────────────── */}
      <div className="border-t border-slate-700" />

      {/* ── Skills / Personas ───────────────────────────────────────── */}
      <div className="px-5 py-4 space-y-4">

        {/* Resume: secondary personas */}
        {isResume && secondaryPersonas.length > 0 && (
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              Also profiled as
            </p>
            <div className="flex flex-wrap gap-2">
              {secondaryPersonas.map((p, i) => (
                <Chip key={i} label={typeof p === "string" ? p : entityLabel(p)} variant="violet" />
              ))}
            </div>
          </div>
        )}

        {/* JD: must-have skills */}
        {isJD && mustHaveSkills.length > 0 && (
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              Must-Have Skills
            </p>
            <div className="flex flex-wrap gap-2">
              {mustHaveSkills.map((s, i) => (
                <Chip key={i} label={entityLabel(s)} variant="brand" />
              ))}
            </div>
          </div>
        )}

        {/* JD: nice-to-have skills */}
        {isJD && niceToHaveSkills.length > 0 && (
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              Nice-to-Have
            </p>
            <div className="flex flex-wrap gap-2">
              {niceToHaveSkills.map((s, i) => (
                <Chip key={i} label={entityLabel(s)} variant="slate" />
              ))}
            </div>
          </div>
        )}

        {/* Resume: top entities from Summary segment */}
        {isResume && data.segments?.Summary?.entities?.length > 0 && (
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              Key Technologies (from Summary)
            </p>
            <div className="flex flex-wrap gap-2">
              {data.segments.Summary.entities.slice(0, 10).map((e, i) => (
                <Chip key={i} label={entityLabel(e)} variant="brand" />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── File meta footer ────────────────────────────────────────── */}
      {data._meta && (
        <>
          <div className="border-t border-slate-700" />
          <div className="flex flex-wrap gap-x-6 gap-y-1 px-5 py-3 text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <svg className="h-3.5 w-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414
                     A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              {data._meta.original_filename}
            </span>
            <span className="flex items-center gap-1.5">
              <svg className="h-3.5 w-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4
                     8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
              </svg>
              {data._meta.file_size_mb} MB
            </span>
            <span className="flex items-center gap-1.5">
              <svg className="h-3.5 w-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {new Date(data._meta.parsed_at).toLocaleString()}
            </span>
            {data._id && (
              <span className="flex items-center gap-1.5 font-mono">
                <svg className="h-3.5 w-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14" />
                </svg>
                {data._id.slice(-8)}
              </span>
            )}
          </div>
        </>
      )}
    </div>
  );
}
