/**
 * StatusBar.jsx
 * ─────────────
 * Shows upload progress, parsing spinner, or error/success banners.
 */
import { STATUS } from "../hooks/useParser";

export default function StatusBar({ status, progress, fileName, error }) {
  if (status === STATUS.IDLE) return null;

  const configs = {
    [STATUS.UPLOADING]: {
      bg: "bg-brand-900/40 border-brand-700",
      icon: "⬆️",
      text: `Uploading ${fileName}…`,
      sub: `${progress}% transferred`,
      showBar: true,
    },
    [STATUS.PARSING]: {
      bg: "bg-violet-900/40 border-violet-700",
      icon: "🧠",
      text: "Model 1 is parsing your document…",
      sub: "GLiNER + transformers running — this may take 15–30 s on CPU.",
      showBar: false,
      spin: true,
    },
    [STATUS.SUCCESS]: {
      bg: "bg-emerald-900/40 border-emerald-700",
      icon: "✅",
      text: `Parsed successfully!`,
      sub: `${fileName} — scroll down to inspect the structured JSON.`,
      showBar: false,
    },
    [STATUS.ERROR]: {
      bg: "bg-red-900/40 border-red-700",
      icon: "❌",
      text: "Parse failed",
      sub: error,
      showBar: false,
    },
  };

  const cfg = configs[status];
  if (!cfg) return null;

  return (
    <div className={`rounded-xl border px-5 py-4 ${cfg.bg}`}>
      <div className="flex items-start gap-3">
        {cfg.spin ? (
          <svg className="w-5 h-5 mt-0.5 animate-spin text-violet-400" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
          </svg>
        ) : (
          <span className="text-lg leading-none">{cfg.icon}</span>
        )}
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-slate-100 text-sm">{cfg.text}</p>
          {cfg.sub && (
            <p className="mt-0.5 text-xs text-slate-400 break-words">{cfg.sub}</p>
          )}
          {cfg.showBar && (
            <div className="mt-2 h-1.5 w-full rounded-full bg-slate-700">
              <div
                className="h-full rounded-full bg-brand-500 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
