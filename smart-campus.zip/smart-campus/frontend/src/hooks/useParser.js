/**
 * useParser.js
 * ────────────
 * Custom React hook that encapsulates all state and logic for PDF upload +
 * parsing. Keeps App.jsx purely presentational.
 */
import { useState, useCallback } from "react";
import { uploadAndParse as uploadPDF } from "../utils/api";

export const STATUS = {
  IDLE: "idle",
  UPLOADING: "uploading",
  PARSING: "parsing",
  SUCCESS: "success",
  ERROR: "error",
};

export function useParser() {
  const [status, setStatus] = useState(STATUS.IDLE);
  const [progress, setProgress] = useState(0);       // 0-100
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState(null);
  const [fileName, setFileName] = useState("");

  const parse = useCallback(async (file) => {
    if (!file) return;

    setFileName(file.name);
    setResult(null);
    setError(null);
    setProgress(0);
    setStatus(STATUS.UPLOADING);

    try {
      const data = await uploadPDF(file, (loaded, total) => {
        const pct = Math.round((loaded / total) * 100);
        setProgress(pct);
        if (pct === 100) setStatus(STATUS.PARSING);
      });

      setResult(data);
      setStatus(STATUS.SUCCESS);
    } catch (err) {
      const msg =
        err?.response?.data?.detail ||
        err?.message ||
        "An unknown error occurred.";
      setError(msg);
      setStatus(STATUS.ERROR);
    }
  }, []);

  const reset = useCallback(() => {
    setStatus(STATUS.IDLE);
    setProgress(0);
    setResult(null);
    setError(null);
    setFileName("");
  }, []);

  return { status, progress, result, error, fileName, parse, reset };
}
