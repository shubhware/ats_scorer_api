/**
 * api.js
 * ───────
 * Centralised Axios instance.
 *
 * In development the Vite proxy (vite.config.js → server.proxy) forwards
 * every /api/* call to http://backend:8000, so we only need a relative base
 * URL here — no CORS issues, no hardcoded ports in component code.
 */
import axios from "axios";

const apiClient = axios.create({
  baseURL: "/",           // relative — Vite proxy handles the actual target
  timeout: 300000,        // 5 min: model inference can be slow on first run
  headers: {
    Accept: "application/json",
  },
});

// ── Request interceptor (log in dev) ─────────────────────────────────────────
apiClient.interceptors.request.use((config) => {
  if (import.meta.env.DEV) {
    console.debug(`[API] ${config.method?.toUpperCase()} ${config.url}`);
  }
  return config;
});

// ── Response interceptor (normalise errors) ───────────────────────────────────
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.detail ||
      error.response?.data?.message ||
      error.message ||
      "Unknown error";
    return Promise.reject(new Error(message));
  }
);

/**
 * Upload a PDF file and return the Model 1 parse result.
 * @param {File} file
 * @param {function} onUploadProgress - optional progress callback (0-100)
 * @returns {Promise<object>} parsed JSON from the backend
 */
export async function uploadAndParse(file, onUploadProgress) {
  const formData = new FormData();
  formData.append("file", file);

  const { data } = await apiClient.post("/api/parser/upload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (evt) => {
      if (onUploadProgress && evt.total) {
        onUploadProgress(Math.round((evt.loaded * 100) / evt.total));
      }
    },
  });

  return data;
}

/**
 * Fetch the parse history from MongoDB.
 */
export async function fetchParseHistory(limit = 20) {
  const { data } = await apiClient.get(`/api/parser/history?limit=${limit}`);
  return data;
}

export default apiClient;
