import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",   // required to accept connections from host machine
    port: 5173,
    watch: {
      usePolling: true, // needed inside Docker for file-change detection
    },
    // Proxy API calls to the backend container so CORS is handled cleanly
    // in development even before the browser hits the real backend.
    proxy: {
      "/api": {
        target: "http://backend:8000",
        changeOrigin: true,
      },
    },
  },
});
