# Smart Campus Recruitment System — Local Setup Guide

> **Goal:** Run the full stack (FastAPI backend + React frontend + MongoDB)  
> on your local machine using Docker, with a single command.

---

## Prerequisites

| Tool | Minimum Version | Check |
|------|----------------|-------|
| Docker Desktop | 24.x | `docker --version` |
| Docker Compose | v2.x (bundled with Desktop) | `docker compose version` |
| Git | Any | `git --version` |

> **Windows users:** Enable WSL 2 backend in Docker Desktop → Settings → General.

---

## 1. Clone & Enter the Project

```bash
git clone <your-repo-url> smart-campus
cd smart-campus
```

If you have the folder already:

```bash
cd /path/to/smart-campus
```

---

## 2. First-Time Build & Start (takes 5–15 min)

```bash
docker compose up --build
```

What happens:
- **mongodb** — pulls `mongo:7.0`, creates a persistent volume `mongo_data`
- **backend** — installs Python deps (spaCy, GLiNER, transformers, etc.), downloads `en_core_web_sm`
- **frontend** — runs `npm install` and starts Vite dev server with HMR

All three containers are networked together via `campus_net`.

---

## 3. Access the App

| Service | URL |
|---------|-----|
| React frontend | http://localhost:5173 |
| FastAPI docs (Swagger) | http://localhost:8000/docs |
| FastAPI health check | http://localhost:8000/health |
| MongoDB (from host) | mongodb://admin:campus_secret@localhost:27017 |

---

## 4. Day-to-Day Commands

### Start (after first build)
```bash
docker compose up
```

### Start in background (detached)
```bash
docker compose up -d
```

### Stop all containers
```bash
docker compose down
```

### Stop and remove volumes (wipes MongoDB data)
```bash
docker compose down -v
```

### Rebuild a single service (e.g. after adding a pip package)
```bash
docker compose up --build backend
```

### View live logs
```bash
# All services
docker compose logs -f

# Backend only
docker compose logs -f backend

# Frontend only
docker compose logs -f frontend
```

### Open a shell inside the backend container
```bash
docker compose exec backend bash
```

### Open MongoDB shell
```bash
docker compose exec mongodb mongosh \
  --username admin --password campus_secret \
  --authenticationDatabase admin \
  smart_campus
```

---

## 5. Integrating Your Model 1 Code

Open `backend/api/routes/parser.py` and find the function:

```python
def run_model_1_parser(file_path: str) -> dict:
```

Replace the stub body with your notebook logic. The function receives the
**absolute path** to the uploaded PDF as a string and must return a **dict**.

Example skeleton:

```python
def run_model_1_parser(file_path: str) -> dict:
    import fitz
    import spacy
    from gliner import GLiNER

    # Load models (consider caching at module level for performance)
    nlp = spacy.load("en_core_web_sm")
    gliner = GLiNER.from_pretrained("urchade/gliner_medium-v2.1")

    # Extract text
    doc = fitz.open(file_path)
    text = "\n".join(page.get_text() for page in doc)
    doc.close()

    # --- YOUR MODEL 1 LOGIC HERE ---
    result = { ... }   # your parsed output dict
    return result
```

After saving, the backend hot-reloads automatically (no rebuild needed).

---

## 6. Adding Python Packages

1. Add the package to `backend/requirements.txt`
2. Rebuild the backend image:

```bash
docker compose up --build backend
```

---

## 7. Environment Variables

All variables are set in `docker-compose.yml`. To override locally, create a
`.env` file in the project root:

```env
# .env (gitignored — never commit this)
MONGO_INITDB_ROOT_PASSWORD=my_strong_password
```

Then reference it in `docker-compose.yml` with `${VAR_NAME}` syntax.

---

## 8. Troubleshooting

### "Port already in use"
```bash
# Find and kill the process using the port
lsof -ti:8000 | xargs kill -9
lsof -ti:5173 | xargs kill -9
lsof -ti:27017 | xargs kill -9
```

### Backend can't connect to MongoDB
The backend `depends_on` a MongoDB healthcheck. If it fails:
```bash
docker compose logs mongodb
# Re-run after MongoDB is healthy
docker compose restart backend
```

### Frontend HMR not working (file changes not reflected)
The Vite config uses `usePolling: true` for Docker compatibility.
If you still have issues, try:
```bash
docker compose restart frontend
```

### Clearing Python model cache (force re-download)
```bash
docker compose down
docker volume prune   # removes unnamed volumes
docker compose up --build backend
```

### Full nuclear reset (removes all images + volumes)
```bash
docker compose down -v --rmi local
docker compose up --build
```

---

## 9. Project Structure Quick Reference

```
smart-campus/
├── docker-compose.yml          # Orchestrates all 3 services
├── .env                        # (create manually, gitignored)
│
├── backend/
│   ├── Dockerfile              # Python 3.11, spaCy, GLiNER, transformers
│   ├── requirements.txt        # All Python dependencies
│   ├── main.py                 # FastAPI app + CORS + lifespan
│   ├── database.py             # Motor async MongoDB connection
│   └── api/
│       └── routes/
│           └── parser.py       # POST /api/parser/upload  ← paste Model 1 here
│
└── frontend/
    ├── Dockerfile              # Node 20, Vite dev server
    ├── package.json
    ├── vite.config.js          # Proxy /api → backend:8000
    ├── tailwind.config.js
    └── src/
        ├── App.jsx             # Main UI
        ├── utils/api.js        # Axios client + uploadAndParse()
        └── components/
            ├── UploadZone.jsx  # Drag-and-drop PDF uploader
            ├── JsonViewer.jsx  # Syntax-highlighted collapsible JSON tree
            └── StatusBadge.jsx # Coloured pill labels
```
